SEED = 2026

DEVELOPMENT_PATH = '../data/development.csv'

OPTUNA_TRIALS = 2
OPTUNA_KSPLITS = 2

COLUMNS_TO_DROP = ['article', 'title', 'source', 'timestamp']