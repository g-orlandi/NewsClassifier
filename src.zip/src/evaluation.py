from sklearn.model_selection import train_test_split
from scipy import sparse
import pandas as pd

from .preprocessing import *
from .utils import load_data
from . import models
from .hyperparams_opt import optuna_hyp_opt

def evaluate(models_name=['naive_bayes', 'xgboost', 'linear_svm'], version=0):
    news_df = load_data()
    prep = Preprocessor()

    X = news_df.drop(columns=['y'])
    y = news_df['y']

    Xtr_val, X_test, ytr_val, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=SEED)

    print(f'Beginning shapes: \nXtr_val: {Xtr_val.shape} | X_test: {X_test.shape} | ytr_val: {ytr_val.shape} | y_test: {y_test.shape}')

    Xtr_val_prep, idxs = prep.fit(Xtr_val.copy())
    ytr_val_prep = ytr_val.loc[idxs]

    X_test_prep, idxs = prep.transform(X_test.copy())
    y_test_prep = y_test.loc[idxs]

    print(f'Prep shapes: \nXtr_val: {Xtr_val_prep.shape} | X_test: {X_test_prep.shape} | ytr_val: {ytr_val_prep.shape} | y_test: {y_test_prep.shape}')

    all_models_results = {}
    all_hyperparams = {}

    if isinstance(models_name, str):
        models_name = [models_name]

    for model_name in models_name:
        function_name = model_name + "_performances"

        function = getattr(models, function_name)

        # TO-DO: eventually scale

        hyperparams = optuna_hyp_opt(model_name, function, Xtr_val, ytr_val, version)

        result = function(
            hyperparams, 
            Xtr_val_prep, X_test_prep, ytr_val_prep, y_test_prep
        )

        all_models_results[model_name] = result
        all_hyperparams[model_name] = hyperparams

    models_results_df = pd.DataFrame(all_models_results)

    return models_results_df, all_hyperparams

